package 프로젝트2차ver2;

public class 독서실클래스2 {

	private int 좌석번호;
	private String 조명;
	private String 콘센트;
	private String 칸막이;
	private String 컴퓨터;
	private String 주의사항;

	public 독서실클래스2() {

	}

	public 독서실클래스2(int 좌석번호, String 조명, String 콘센트, String 칸막이, String 컴퓨터, String 주의사항) {
		super();
		this.좌석번호 = 좌석번호;
		this.조명 = 조명;
		this.콘센트 = 콘센트;
		this.칸막이 = 칸막이;
		this.컴퓨터 = 컴퓨터;
		this.주의사항 = 주의사항;
	}

	@Override
	public String toString() {
		return "독서실클래스2 [좌석번호=" + 좌석번호 + ", 조명=" + 조명 + ", 콘센트=" + 콘센트 + ", 칸막이=" + 칸막이 + ", 컴퓨터=" + 컴퓨터 + ", 주의사항="
				+ 주의사항 + "]";
	}

}
